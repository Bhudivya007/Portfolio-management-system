from django.apps import AppConfig


class RiskprofileConfig(AppConfig):
    name = 'riskprofile'
